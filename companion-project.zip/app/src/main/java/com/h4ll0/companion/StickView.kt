package com.h4ll0.companion

import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.view.View
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

enum class Mood { IDLE, HAPPY, SLEEPY, SURPRISED, WAVE, NOTICE, WALK }

class StickView(c: Context) : View(c) {
    var mood = Mood.IDLE
    var bodyColor = Color.WHITE
        set(v) { field = v; postInvalidate() }

    private var blink = false
    private var waveAngle = 0f
    private var legPhase = 0f
    private val handler = Handler(Looper.myLooper()!!)
    private var anim: Runnable? = null

    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(235, 25, 16, 16); style = Paint.Style.STROKE
        strokeWidth = 5f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val limbOutline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(235, 25, 16, 16); style = Paint.Style.STROKE
        strokeWidth = 13f; strokeCap = Paint.Cap.ROUND
    }
    private val limbFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 8f; strokeCap = Paint.Cap.ROUND
    }
    private val feature = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(240, 25, 16, 16); style = Paint.Style.FILL; strokeWidth = 5f; strokeCap = Paint.Cap.ROUND
    }
    private val featureStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(240, 25, 16, 16); style = Paint.Style.STROKE; strokeWidth = 5f; strokeCap = Paint.Cap.ROUND
    }
    private val blush = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(70, 255, 90, 110); style = Paint.Style.FILL }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(70, 0, 0, 0); style = Paint.Style.FILL }

    init {
        postDelayed(object : Runnable {
            override fun run() {
                if (mood != Mood.SLEEPY) { blink = true; postInvalidate(); postDelayed({ blink = false; postInvalidate() }, 120) }
                postDelayed(this, Random.nextLong(2000, 5000))
            }
        }, 2000)
    }

    private fun runFor(ms: Long, onTick: (Float) -> Unit, onDone: () -> Unit) {
        anim?.let { handler.removeCallbacks(it) }
        val start = System.currentTimeMillis()
        val r = object : Runnable {
            override fun run() {
                val t = (System.currentTimeMillis() - start) / 1000f
                onTick(t); postInvalidate()
                if (t * 1000 < ms) handler.postDelayed(this, 16) else onDone()
            }
        }
        anim = r; handler.post(r)
    }

    fun wake() { mood = Mood.WAVE; runFor(2400, { t -> waveAngle = sin(t * 9) * 35f }, { mood = Mood.IDLE; postInvalidate() }) }
    fun notice() { mood = Mood.NOTICE; runFor(1900, { }, { mood = Mood.IDLE; postInvalidate() }) }
    fun setWalking(walking: Boolean, stepPhase: Float) { legPhase = stepPhase; mood = if (walking) Mood.WALK else Mood.IDLE; postInvalidate() }

    private fun limb(cv: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        cv.drawLine(x1, y1, x2, y2, limbOutline)
        cv.drawLine(x1, y1, x2, y2, limbFill)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2; val cy = h * 0.5f; val r = h * 0.2f

        limbFill.color = bodyColor
        val shade = Color.rgb(
            (Color.red(bodyColor) * 0.75f).toInt(), (Color.green(bodyColor) * 0.75f).toInt(), (Color.blue(bodyColor) * 0.75f).toInt()
        )
        fillP.shader = RadialGradient(cx - r * 0.35f, cy - r * 0.4f, r * 1.6f, bodyColor, shade, Shader.TileMode.CLAMP)

        val neck = cy + r * 0.95f
        val hip = neck + r * 1.5f

        // bayangan di bawah kaki
        cv.drawOval(RectF(cx - r * 0.9f, hip + r * 1.15f, cx + r * 0.9f, hip + r * 1.45f), shadow)

        // badan (kapsul)
        val bodyRect = RectF(cx - r * 0.55f, neck - r * 0.1f, cx + r * 0.55f, hip + r * 0.15f)
        cv.drawRoundRect(bodyRect, r * 0.55f, r * 0.55f, fillP)
        cv.drawRoundRect(bodyRect, r * 0.55f, r * 0.55f, outline)

        // tangan & kaki
        val armY = neck + r * 0.35f
        when (mood) {
            Mood.WAVE -> {
                limb(cv, cx, armY, cx - r * 0.75f, armY + r * 0.35f)
                val a = Math.toRadians((90 - waveAngle).toDouble())
                limb(cv, cx, armY, cx + (r * 0.85f * cos(a)).toFloat(), armY - (r * 0.85f * sin(a)).toFloat())
            }
            Mood.NOTICE -> {
                limb(cv, cx, armY, cx - r * 0.3f, cy + r * 0.1f)
                limb(cv, cx, armY, cx + r * 0.3f, cy - r * 0.55f)
            }
            else -> {
                val sw = if (mood == Mood.HAPPY) r * 0.45f else r * 0.3f
                limb(cv, cx, armY, cx - r * 0.85f, armY - sw)
                limb(cv, cx, armY, cx + r * 0.85f, armY - sw)
            }
        }
        if (mood == Mood.WALK) {
            val stride = sin(legPhase) * r * 0.5f
            limb(cv, cx, hip, cx - r * 0.45f + stride, hip + r * 1.3f)
            limb(cv, cx, hip, cx + r * 0.45f - stride, hip + r * 1.3f)
        } else {
            limb(cv, cx, hip, cx - r * 0.5f, hip + r * 1.3f)
            limb(cv, cx, hip, cx + r * 0.5f, hip + r * 1.3f)
        }

        // kepala
        fillP.shader = RadialGradient(cx - r * 0.35f, cy - r * 0.45f, r * 1.7f, bodyColor, shade, Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, r, fillP)
        cv.drawCircle(cx, cy, r, outline)
        fillP.shader = null

        // pipi blush
        if (mood != Mood.SLEEPY) {
            cv.drawCircle(cx - r * 0.55f, cy + r * 0.12f, r * 0.17f, blush)
            cv.drawCircle(cx + r * 0.55f, cy + r * 0.12f, r * 0.17f, blush)
        }

        val eyeOffset = when (mood) { Mood.SURPRISED, Mood.WAVE -> r * 0.36f; else -> r * 0.32f }
        val eyeY = cy - r * 0.1f
        if (blink) {
            cv.drawLine(cx - eyeOffset - 9f, eyeY, cx - eyeOffset + 9f, eyeY, featureStroke)
            cv.drawLine(cx + eyeOffset - 9f, eyeY, cx + eyeOffset + 9f, eyeY, featureStroke)
        } else when (mood) {
            Mood.SLEEPY -> {
                cv.drawLine(cx - eyeOffset - 9f, eyeY, cx - eyeOffset + 9f, eyeY, featureStroke)
                cv.drawLine(cx + eyeOffset - 9f, eyeY, cx + eyeOffset + 9f, eyeY, featureStroke)
            }
            Mood.SURPRISED, Mood.NOTICE -> {
                cv.drawCircle(cx - eyeOffset, eyeY, 8f, feature)
                cv.drawCircle(cx + eyeOffset, eyeY, 8f, feature)
                cv.drawCircle(cx - eyeOffset - 2f, eyeY - 2f, 2.5f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
                cv.drawCircle(cx + eyeOffset - 2f, eyeY - 2f, 2.5f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
            }
            Mood.HAPPY, Mood.WAVE -> {
                cv.drawArc(RectF(cx - eyeOffset - 9f, eyeY - 9f, cx - eyeOffset + 9f, eyeY + 11f), 200f, 140f, false, featureStroke)
                cv.drawArc(RectF(cx + eyeOffset - 9f, eyeY - 9f, cx + eyeOffset + 9f, eyeY + 11f), 200f, 140f, false, featureStroke)
            }
            else -> {
                cv.drawCircle(cx - eyeOffset, eyeY, 5.5f, feature)
                cv.drawCircle(cx + eyeOffset, eyeY, 5.5f, feature)
                cv.drawCircle(cx - eyeOffset - 1.5f, eyeY - 1.5f, 1.8f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
                cv.drawCircle(cx + eyeOffset - 1.5f, eyeY - 1.5f, 1.8f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
            }
        }
        val mouthY = cy + r * 0.4f
        when (mood) {
            Mood.HAPPY, Mood.WAVE -> cv.drawArc(RectF(cx - r * 0.38f, mouthY - 15f, cx + r * 0.38f, mouthY + 15f), 10f, 160f, false, featureStroke)
            Mood.SURPRISED, Mood.NOTICE -> cv.drawCircle(cx, mouthY, 9f, feature)
            Mood.SLEEPY -> cv.drawLine(cx - 10f, mouthY, cx + 10f, mouthY, featureStroke)
            else -> cv.drawArc(RectF(cx - r * 0.22f, mouthY - 6f, cx + r * 0.22f, mouthY + 12f), 15f, 150f, false, featureStroke)
        }
    }
}
