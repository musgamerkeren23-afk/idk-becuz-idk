package com.h4ll0.companion

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color as CColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Red = CColor(0xFFE0262E)
private val Swatches = listOf(
    CColor(0xFFFFFFFF), CColor(0xFFE0262E), CColor(0xFF2E8CFF), CColor(0xFF2ECC71),
    CColor(0xFFFFD23F), CColor(0xFFB86BFF), CColor(0xFFFF8C42), CColor(0xFF22D3EE)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = CColor(0xFF0D0A0A), surface = CColor(0xFF191212))) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }
    fun hasOverlay() = Settings.canDrawOverlays(this)
    fun hasUsage(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }
    fun start() {
        val i = Intent(this, CompanionService::class.java)
        if (Build.VERSION.SDK_INT >= 26) ContextCompat.startForegroundService(this, i) else startService(i)
    }
    fun stop() = stopService(Intent(this, CompanionService::class.java))
}

@Composable
fun App() {
    val a = androidx.compose.ui.platform.LocalContext.current as MainActivity
    val prefs = remember { a.getSharedPreferences("companion", Context.MODE_PRIVATE) }
    var overlayOk by remember { mutableStateOf(a.hasOverlay()) }
    var usageOk by remember { mutableStateOf(a.hasUsage()) }
    var running by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf(prefs.getString("name", "Teman") ?: "Teman") }
    var color by remember { mutableStateOf(CColor(prefs.getInt("color", Color.WHITE))) }
    val lOverlay = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { overlayOk = a.hasOverlay() }
    val lUsage = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { usageOk = a.hasUsage() }

    fun applyNow() {
        prefs.edit().putString("name", name).putInt("color", color.toArgb()).apply()
        if (running) CompanionService.applyUpdate(name, color.toArgb())
    }

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Teman Digital", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Red)
        Spacer(Modifier.height(16.dp))

        if (!overlayOk) {
            Text("1. Izinkan tampil di atas app lain:", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Button({ lOverlay.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${a.packageName}"))) }) { Text("Buka izin overlay") }
        } else if (!usageOk) {
            Text("2. Izinkan Usage Access (opsional, biar dia sadar pas kamu pindah app):", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Button({ lUsage.launch(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }) { Text("Buka Usage Access") }
            Spacer(Modifier.height(10.dp))
            OutlinedButton({ usageOk = true }) { Text("Lewati, gak penting") }
        } else {
            OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Nama teman digitalmu") }, singleLine = true)
            Spacer(Modifier.height(14.dp))
            Text("Warna tubuh", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Swatches.forEach { sw ->
                    Box(
                        Modifier.size(36.dp).clip(CircleShape).background(sw)
                            .border(if (sw == color) 3.dp else 1.dp, if (sw == color) Red else CColor.Gray, CircleShape)
                            .clickable { color = sw }
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Button({ applyNow() }, Modifier.fillMaxWidth()) { Text("Terapkan") }
            Spacer(Modifier.height(20.dp))
            if (!running) Button({ a.start(); running = true; applyNow() }, Modifier.fillMaxWidth()) { Text("Panggil ${name.ifBlank { "dia" }}") }
            else OutlinedButton({ a.stop(); running = false }, Modifier.fillMaxWidth()) { Text("Suruh dia pergi dulu") }
        }
    }
}
