package com.h4ll0.companion

import android.app.*
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import kotlin.math.abs
import kotlin.math.max
import kotlin.random.Random

class CompanionService : Service() {
    companion object {
        var instance: CompanionService? = null
        fun applyUpdate(name: String, color: Int) {
            instance?.let { it.compName = name; it.view?.bodyColor = color; it.view?.notice(); it.updateNotif() }
        }
    }

    private lateinit var wm: WindowManager
    private var view: StickView? = null
    private val handler = Handler(Looper.myLooper()!!)
    private var lastApp = ""
    private var lastTouch = System.currentTimeMillis()
    private var compName = "Teman"
    private var winParams: WindowManager.LayoutParams? = null
    private var walking = false

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_SCREEN_ON) { lastTouch = System.currentTimeMillis(); view?.wake() }
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val prefs = getSharedPreferences("companion", MODE_PRIVATE)
        compName = prefs.getString("name", "Teman") ?: "Teman"
        startForeground(2, notif())
        addView(prefs.getInt("color", android.graphics.Color.WHITE))
        pollLoop()
        walkLoop()
        registerReceiver(screenReceiver, IntentFilter(Intent.ACTION_SCREEN_ON))
    }

    private fun notif(): Notification {
        val ch = "companion"
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(ch, "Teman Digital", NotificationManager.IMPORTANCE_MIN)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(c)
        }
        return NotificationCompat.Builder(this, ch)
            .setContentTitle("$compName aktif")
            .setContentText("Tap dia buat nyapa")
            .setSmallIcon(android.R.drawable.sym_def_app_icon)
            .setOngoing(true).build()
    }
    private fun updateNotif() {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(2, notif())
    }

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun addView(color: Int) {
        val sv = StickView(this)
        sv.bodyColor = color
        val size = (150 * resources.displayMetrics.density).toInt()
        val p = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = 40; p.y = 300
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        sv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    p.x = sx + (e.rawX - dx).toInt(); p.y = sy + (e.rawY - dy).toInt()
                    if (max(abs(e.rawX - dx), abs(e.rawY - dy)) > 12) moved = true
                    wm.updateViewLayout(sv, p); true
                }
                MotionEvent.ACTION_UP -> { lastTouch = System.currentTimeMillis(); if (!moved) react(sv, Mood.HAPPY); true }
                else -> false
            }
        }
        wm.addView(sv, p)
        view = sv; winParams = p
    }

    private fun react(sv: StickView, m: Mood, back: Mood = Mood.IDLE, holdMs: Long = 1800) {
        if (walking) return
        sv.mood = m; sv.postInvalidate()
        handler.postDelayed({ if (sv.mood == m) { sv.mood = back; sv.postInvalidate() } }, holdMs)
    }

    private fun pollLoop() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                val sv = view
                if (sv != null && !walking) {
                    val idleMs = System.currentTimeMillis() - lastTouch
                    if (idleMs > 90_000 && sv.mood == Mood.IDLE) { sv.mood = Mood.SLEEPY; sv.postInvalidate() }
                    else if (idleMs < 90_000 && sv.mood == Mood.SLEEPY) { sv.mood = Mood.IDLE; sv.postInvalidate() }
                    checkForegroundApp(sv)
                }
                handler.postDelayed(this, 3000)
            }
        }, 3000)
    }

    /** Jalan-jalan sendiri ke titik acak di layar tiap beberapa detik. */
    private fun walkLoop() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                val sv = view; val p = winParams
                if (sv != null && p != null && sv.mood != Mood.SLEEPY && sv.mood != Mood.WAVE && sv.mood != Mood.NOTICE) {
                    val maxX = resources.displayMetrics.widthPixels - sv.width
                    val target = Random.nextInt(0, max(1, maxX))
                    walkTo(sv, p, target)
                }
                handler.postDelayed(this, Random.nextLong(9000, 16000))
            }
        }, 6000)
    }

    private fun walkTo(sv: StickView, p: WindowManager.LayoutParams, targetX: Int) {
        val startX = p.x; val dist = targetX - startX
        if (abs(dist) < 40) return
        walking = true
        val durMs = (abs(dist) / 0.25f).toLong().coerceIn(1200, 4000)
        val start = System.currentTimeMillis()
        val step = object : Runnable {
            override fun run() {
                val t = ((System.currentTimeMillis() - start).toFloat() / durMs).coerceIn(0f, 1f)
                p.x = startX + (dist * t).toInt()
                runCatching { wm.updateViewLayout(sv, p) }
                sv.setWalking(true, t * 20f)
                if (t < 1f) handler.postDelayed(this, 16)
                else { walking = false; sv.setWalking(false, 0f) }
            }
        }
        handler.post(step)
    }

    private fun checkForegroundApp(sv: StickView) {
        try {
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val end = System.currentTimeMillis(); val begin = end - 10_000
            val events = usm.queryEvents(begin, end)
            var current = lastApp
            val ev = android.app.usage.UsageEvents.Event()
            while (events.hasNextEvent()) { events.getNextEvent(ev); if (ev.eventType == android.app.usage.UsageEvents.Event.MOVE_TO_FOREGROUND) current = ev.packageName }
            if (current.isNotEmpty() && lastApp.isNotEmpty() && current != lastApp) react(sv, Mood.SURPRISED)
            lastApp = current
        } catch (_: Exception) { }
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        view?.let { runCatching { wm.removeView(it) } }
        handler.removeCallbacksAndMessages(null)
        runCatching { unregisterReceiver(screenReceiver) }
    }
}
